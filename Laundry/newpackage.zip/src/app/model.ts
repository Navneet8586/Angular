export interface timeSlotFilter{
    idx:number;
    value:number;
}

export enum contact{
    NUMBER='9718062188',
    ALTNUMBER='9818762188',
    ADDRESS='shop no-ug-05,Near Barat Ghar Kuleshra,Greater Noida,GB Nagar,201306',
    EMAIL='Grenocleaners@gmail.com'
}
export const services=['Laundry','Dry Cleaning','Steam Ironing','Sofa Cleaning','Carpet Cleaning','Shoe Spa','Polishing'];
