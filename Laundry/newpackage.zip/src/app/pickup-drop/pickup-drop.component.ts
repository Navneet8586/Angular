import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { timeSlotFilter } from '../model';
import { LaundryService } from '../laundry.service';

@Component({
  selector: 'app-pickup-drop',
  templateUrl: './pickup-drop.component.html',
  styleUrls: ['./pickup-drop.component.css']
})
export class PickupDropComponent implements OnInit {
  pickupDrop!: FormGroup;
  timeslotflag=false;

  services=['Laundry','Dry Cleaning','Steam Ironing','Sofa Cleaning','Carpet Cleaning','Shoe Spa','Polishing'];
  copyslot=['10:00-11:00','11:00-12:00','12:00-01:00','01:00-02:00','02:00-03:00','03:00-04:00','04:00-05:00','05:00-06:00','06:00-07:00','07:00-08:00'];
  timeSlots=['10:00-11:00','11:00-12:00','12:00-01:00','01:00-02:00','02:00-03:00','03:00-04:00','04:00-05:00','05:00-06:00','06:00-07:00','07:00-08:00'];
  timeSlotFilter:timeSlotFilter[]=[];

  constructor(private formBuilder:FormBuilder,private laundryService:LaundryService) { 
    
  }

  ngOnInit(): void {
    this.pickupDrop=this.formBuilder.group({
      name:['',Validators.required],
      email:['',Validators.required],
      selectedService:['',Validators.required],
      selectedDate:['',Validators.required],
      selectedTimeSlot:['',Validators.required]
    })
  }
  callNow(){
    window.location.href='tel:8005657266';
    
    //console.log(date.getUTCDate()+""+date.getUTCMonth()+""+date.getUTCFullYear());
  }

  onDateSelected(event:any){
    let date=new Date();
    const enteredDate=new Date(event.value);
    if(event.value.toDateString()===date.toDateString()){
      let p=new Date(date.getTime()+2*60*60*1000);
      let value=10;
      for(let i=0;i<this.timeSlotFilter.length;i++){
         this.timeSlotFilter.push({idx:i,value});
         value++;
      }
      let idx=this.timeSlotFilter.find(obj=>obj.value===p.getHours());
      console.log(idx);
      if(idx===undefined){
        this.timeSlots.splice(0,this.timeSlots.length);
        const timeSlotElement=document.getElementById('timeSlot');
        if(timeSlotElement){
          this.timeslotflag=true;
          timeSlotElement.innerText="No Available Time slot for selected date";
        }
       } else{
        this.timeSlots.splice(0,idx.idx);
      }
    } else if(enteredDate<date){
      this.timeSlots.splice(0,this.timeSlots.length);
      const timeSlotElement=document.getElementById('timeSlot');
      if(timeSlotElement){
        this.timeslotflag=true;
        timeSlotElement.innerText="Please select valid Date";
      }
    } else{
      this.timeslotflag=false;
      this.timeSlots=this.copyslot;
    }
    
    
  }

  onSubmit(){
    console.log(this.pickupDrop.value);
    this.laundryService.sendFormDataViaWhatsapp(this.pickupDrop.value);
    this.pickupDrop.reset();
  }

}
